import java.util.*;

public class Main {

    static Random r = new Random();

    public static void midpoint(double x1, double y1,
                                double x2, double y2,
                                double rough, int d) {

        if (d == 0) return;

        double mx = (x1 + x2) / 2;
        double my = (y1 + y2) / 2;

        double off = rough * (r.nextDouble() * 2 - 1);
        my = my + off;

        midpoint(x1, y1, mx, my, rough, d - 1);
        midpoint(mx, my, x2, y2, rough, d - 1);
    }

    public static double[][] terrain(int w, int h, double rough, int d) {

        double[][] g = new double[w][h];

        g[0][0] = 0;
        g[0][h - 1] = 0;
        g[w - 1][0] = 0;
        g[w - 1][h - 1] = 0;

        ds(g, rough, d);

        return g;
    }

    public static void ds(double[][] g, double rough, int d) {

        if (d == 0) return;

        int n = g.length;

        for (int i = 0; i < n - 1; i += 2) {
            for (int j = 0; j < n - 1; j += 2) {

                double avg = (g[i][j] + g[i + 1][j]
                        + g[i][j + 1] + g[i + 1][j + 1]) / 4;

                g[i][j] = avg + rough * (Math.random() * 2 - 1);
            }
        }

        ds(g, rough / 2, d - 1);
    }
    
    public static List<String> detect(double[][] g, double t) {

        List<String> res = new ArrayList<>();

        int n = g.length;
        int m = g[0].length;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if (i + 1 < n) {
                    if (Math.abs(g[i][j] - g[i + 1][j]) > t) {
                        res.add(i + "," + j);
                        continue;
                    }
                }

                if (j + 1 < m) {
                    if (Math.abs(g[i][j] - g[i][j + 1]) > t) {
                        res.add(i + "," + j);
                    }
                }
            }
        }

        return res;
    }

    public static void main(String[] args) {

        midpoint(0, 0, 10, 10, 1, 3);

        double[][] g = terrain(8, 8, 1, 3);

        List<String> a = detect(g, 0.5);

        System.out.println("done");
    }
}