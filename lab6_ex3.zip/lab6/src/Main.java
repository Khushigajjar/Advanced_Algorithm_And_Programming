import java.util.*;

class GeneralizedCategoryNode {
    int id;
    String name;
    int postCount;
    List<GeneralizedCategoryNode> children;
    GeneralizedCategoryNode parent;

    GeneralizedCategoryNode(int id, String name, int postCount) {
        this.id = id;
        this.name = name;
        this.postCount = postCount;
        this.children = new ArrayList<>();
    }
}

class BinaryTreeNode {
    int id;
    String name;
    int postCount;
    BinaryTreeNode left;
    BinaryTreeNode right;

    BinaryTreeNode(int id, String name, int postCount) {
        this.id = id;
        this.name = name;
        this.postCount = postCount;
    }
}

public class Main {

    static GeneralizedCategoryNode binaryToGeneralized(BinaryTreeNode root) {
        if (root == null) return null;

        GeneralizedCategoryNode node =
                new GeneralizedCategoryNode(root.id, root.name, root.postCount);

        BinaryTreeNode child = root.left;

        while (child != null) {
            GeneralizedCategoryNode c = binaryToGeneralized(child);
            c.parent = node;
            node.children.add(c);
            child = child.right;
        }

        return node;
    }

    static BinaryTreeNode generalizedToBinary(GeneralizedCategoryNode root) {
        if (root == null) return null;

        BinaryTreeNode node =
                new BinaryTreeNode(root.id, root.name, root.postCount);

        if (root.children.size() == 0) return node;

        node.left = generalizedToBinary(root.children.get(0));

        BinaryTreeNode cur = node.left;

        for (int i = 1; i < root.children.size(); i++) {
            cur.right = generalizedToBinary(root.children.get(i));
            cur = cur.right;
        }

        return node;
    }

    static void preOrder(GeneralizedCategoryNode node) {
        if (node == null) return;

        System.out.print(node.name + " ");

        for (GeneralizedCategoryNode c : node.children) {
            preOrder(c);
        }
    }

    static void postOrder(GeneralizedCategoryNode node) {
        if (node == null) return;

        for (GeneralizedCategoryNode c : node.children) {
            postOrder(c);
        }

        System.out.print(node.name + " ");
    }

    static void levelOrder(GeneralizedCategoryNode root) {
        if (root == null) return;

        Queue<GeneralizedCategoryNode> q = new LinkedList<>();
        q.add(root);

        while (!q.isEmpty()) {
            GeneralizedCategoryNode cur = q.poll();
            System.out.print(cur.name + " ");

            for (GeneralizedCategoryNode c : cur.children) {
                q.add(c);
            }
        }
    }

    static int countNodes(GeneralizedCategoryNode node) {
        if (node == null) return 0;

        int total = 1;
        for (GeneralizedCategoryNode c : node.children) {
            total += countNodes(c);
        }
        return total;
    }

    static int countLeaves(GeneralizedCategoryNode node) {
        if (node == null) return 0;

        if (node.children.size() == 0) return 1;

        int total = 0;
        for (GeneralizedCategoryNode c : node.children) {
            total += countLeaves(c);
        }
        return total;
    }

    static int height(GeneralizedCategoryNode node) {
        if (node == null) return -1;

        if (node.children.size() == 0) return 0;

        int max = 0;
        for (GeneralizedCategoryNode c : node.children) {
            max = Math.max(max, height(c));
        }

        return max + 1;
    }

    static int fanOut(GeneralizedCategoryNode node) {
        if (node == null) return 0;

        int max = node.children.size();

        for (GeneralizedCategoryNode c : node.children) {
            max = Math.max(max, fanOut(c));
        }

        return max;
    }

    static double branchingFactor(GeneralizedCategoryNode root) {
        int[] r = helper(root);
        if (r[1] == 0) return 0;
        return (double) r[0] / r[1];
    }

    static int[] helper(GeneralizedCategoryNode node) {
        if (node == null) return new int[]{0, 0};

        int totalChildren = 0;
        int nonLeaf = 0;

        if (node.children.size() > 0) {
            totalChildren += node.children.size();
            nonLeaf++;
        }

        for (GeneralizedCategoryNode c : node.children) {
            int[] sub = helper(c);
            totalChildren += sub[0];
            nonLeaf += sub[1];
        }

        return new int[]{totalChildren, nonLeaf};
    }

    public static void main(String[] args) {

        GeneralizedCategoryNode root = new GeneralizedCategoryNode(1, "Technology", 0);
        GeneralizedCategoryNode prog = new GeneralizedCategoryNode(2, "Programming", 0);
        GeneralizedCategoryNode design = new GeneralizedCategoryNode(3, "Design", 0);

        root.children.add(prog);
        root.children.add(design);

        prog.children.add(new GeneralizedCategoryNode(4, "Java", 0));
        prog.children.add(new GeneralizedCategoryNode(5, "Python", 0));

        System.out.print("Pre-order: ");
        preOrder(root);
        System.out.println();

        System.out.print("Level-order: ");
        levelOrder(root);
        System.out.println();

        System.out.println("Nodes: " + countNodes(root));
        System.out.println("Leaves: " + countLeaves(root));
        System.out.println("Height: " + height(root));
        System.out.println("Fan-out: " + fanOut(root));
        System.out.println("Branching factor: " + branchingFactor(root));
    }
}